#!/usr/bin/env sh

#
# CIS-CAT Script Check Engine
#
# Name         Date       Description
# -------------------------------------------------------------------
# E. Pinnell   04/09/21   Check grub options doesn't exist

output="" efidir="" gbdir="" grubfile="" grubext="" passing=""

efidir=$(find /boot/efi/EFI/* -type d -not -name 'BOOT')
gbdir=$(find /boot -maxdepth 1 -type d -name 'grub*')

for file in "$efidir"/grub.cfg "$efidir"/grub.conf; do
	[ -f "$file" ] && grubfile=$file
done
if [ -z "$grubdir" ]; then
	for file in "$gbdir"/grub.cfg "$gbdir"/grub.conf; do
		[ -f "$file" ] && grubfile=$file
	done
fi

grubext="$(echo "$grubfile" | cut -d. -f2)"

if [ -f "$grubfile" ]; then
	if [ "$grubext" = "conf" ]; then
		! grep -P '^\h*kernel.*$' "$grubfile" | grep -Pq "\b$XCCDF_VALUE_REGEX\b" && passing=true
		output="$(grep -P '^\h*kernel.*$' "$grubfile" | grep -P "$\bXCCDF_VALUE_REGEX\b")"
	elif [ "$grubext" = "cfg" ]; then
		! grep "^\h*linux.*$" "$grubfile" | grep -Pq "\b$XCCDF_VALUE_REGEX\b" && passing=true
		output="$(grep -P "^\h*linux.*$" "$grubfile" | grep -P "$\bXCCDF_VALUE_REGEX\b")"
	fi
fi

# If passing is true we pass
if [ "$passing" = true ] ; then
	echo "PASSED"
	exit "${XCCDF_RESULT_PASS:-101}"
else
	# print the reason why we are failing
	echo "FAILED:"
	echo "grub file contains: \"$output\""
	exit "${XCCDF_RESULT_FAIL:-102}"
fi
