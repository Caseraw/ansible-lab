#!/usr/bin/env sh

#
# CIS-CAT Script Check Engine
#
# Name         Date       Description
# -------------------------------------------------------------------
# E. Pinnell   03/23/20   Check that service is stopped and masked
# E. Pinnell   03/12/21   Modified to accept service doesn't exist

passing=""

if systemctl status "$XCCDF_VALUE_REGEX" | grep -qv "Active: active (running) " && systemctl is-enabled "$XCCDF_VALUE_REGEX" | grep -Eq "(masked|does not exist|No such file or directory)"; then
	passing=true
elif ! systemctl is-enabled systemd-timesyncd.service >/dev/null; then
	passing=true
fi

# If the regex matched, output would be generated.  If so, we pass
if [ "$passing" = true ] ; then
	echo "Service $XCCDF_VALUE_REGEX is not running and masked or not presant on the system"
    exit "${XCCDF_RESULT_PASS:-101}"
else
    # print the reason why we are failing
    echo "Service $XCCDF_VALUE_REGEX is running or not masked"
    exit "${XCCDF_RESULT_FAIL:-102}"
fi
