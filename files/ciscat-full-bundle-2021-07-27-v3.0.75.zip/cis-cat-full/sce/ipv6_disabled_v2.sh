#!/usr/bin/env sh

#
# CIS-CAT Script Check Engine
#
# Name         Date       Description
# -------------------------------------------------------------------
# E. Pinnell   02/02/21   Check if IPv6 is disabled
# E. Pinnell   04/08/21   Modified - enhanced setting grub files location
# E. Pinnell   05/14/21   Modified to work with Fedora 28 distributions
# E. Pinnell   07/18/21   Modified to correct false negative

grubfile=$(find -L /boot -type f \( -name 'grubenv' -o -name 'grub.conf' -o -name 'grub.cfg' \) -exec grep -El '^\s*(kernelopts=|linux|kernel)' {} \;)

if [ -s "$grubfile" ]; then
	gfsn=$(printf '%s' "$grubfile" | awk -F'/' '{print $(NF)}')
	if [ "$gfsn" = "grub.conf" ]; then
		! grep "^\s*kernel" "$grubfile" | grep -vq ipv6.disable=1 && passing="true"
	elif [ "$gfsn" = "grub.cfg" ]; then
		! grep "^\s*linux" "$grubfile" | grep -vq ipv6.disable=1 && passing="true"
	elif [ "$gfsn" = "grubenv" ]; then
		! grep "^\s*kernelopts=" "$grubfile" | grep -vq ipv6.disable=1 && passing="true"
	fi
	[ "$passing" = true ] && output="IPv6 Disabled in \"$grubfile\""
fi

# Check network files
if grep -Eqs "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf && grep -Eqs "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b" /etc/sysctl.conf /etc/sysctl.d/*.conf /usr/lib/sysctl.d/*.conf /run/sysctl.d/*.conf && sysctl net.ipv6.conf.all.disable_ipv6 | grep -Eq "^\s*net\.ipv6\.conf\.all\.disable_ipv6\s*=\s*1\b" && sysctl net.ipv6.conf.default.disable_ipv6 | grep -Eq "^\s*net\.ipv6\.conf\.default\.disable_ipv6\s*=\s*1\b"; then
	[ -n "$output" ] && output="$output, and in sysctl config" || output="ipv6 disabled in sysctl config"
	passing="true"
fi

# If the regex matched, output would be generated.  If so, we pass
if [ "$passing" = true ] ; then
	echo "$output"
	exit "${XCCDF_RESULT_PASS:-101}"
else
	# print the reason why we are failing
	echo "IPv6 is enabled on the system"
	exit "${XCCDF_RESULT_FAIL:-102}"
fi
