#!/usr/bin/env sh

#
# CIS-CAT Script Check Engine
#
# Name         Date       Description
# -------------------------------------------------------------------
# E. Pinnell   03/23/20   Check that service is running and not disabled or masked
# E. Pinnell   03/03/21   Modified to allow of active service to be is exited state

passing=""

systemctl status "$XCCDF_VALUE_REGEX" | grep -Eq "Active:\s+active\s+(\(running\)|\(exited\)) " && systemctl is-enabled "$XCCDF_VALUE_REGEX" | grep -q enabled && passing=true

# If the regex matched, output would be generated.  If so, we pass
if [ "$passing" = true ] ; then
	echo "Service $XCCDF_VALUE_REGEX is running and enabled"
    exit "${XCCDF_RESULT_PASS:-101}"
else
    # print the reason why we are failing
    echo "Service $XCCDF_VALUE_REGEX is not running or disabled"
    exit "${XCCDF_RESULT_FAIL:-102}"
fi
